package com.action;





import com.opensymphony.xwork2.ActionSupport;

public class indexAction extends ActionSupport
{
	
	public String index()
	{
		return ActionSupport.SUCCESS;
	}
	
}
